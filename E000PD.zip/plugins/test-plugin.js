export class Plugin {
    onLoad(){
        console.log('load')
        customElements.define('binary-cards', BinaryCards);
        customElements.define('binary-img', ImageToBinary);
    }
}



class BinaryCards extends HTMLElement {
    templateString = `
        <style>
            .binary-cards {
                text-align: center;
            }
            .binary-card {
                position: relative;
                display: inline-block;
                vertical-align: middle;
                width: 50px;
                height: 70px;
                margin: 5px;
                -webkit-perspective: 1000px;
                        perspective: 1000px;
                -webkit-transition: -webkit-transform 0.8s;
                transition: -webkit-transform 0.8s;
                -o-transition: transform 0.8s;
                transition: transform 0.8s;
                transition: transform 0.8s, -webkit-transform 0.8s;
                -webkit-transform-style: preserve-3d;
                        transform-style: preserve-3d;
                -webkit-transform: rotateY(0deg);
                        transform: rotateY(0deg);
            }
            .binary-card:before {
                content: '';
                position: absolute;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                border: 2px solid black;
                -webkit-transform: rotateY(0deg);
                        transform: rotateY(0deg);
                -webkit-backface-visibility: hidden;
                        backface-visibility: hidden;
            }
            .binary-card:after {
                content: '';
                position: absolute;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                border: 2px solid black;
                -webkit-transform: rotateY(180deg);
                        transform: rotateY(180deg);
                -webkit-backface-visibility: hidden;
                        backface-visibility: hidden;
                z-index:1;
            }
            .binary-card.flipped {
                -webkit-transform: rotateY(180deg);
                        transform: rotateY(180deg);
            }
            .binary-card[value="1"]:after {
                background-color: white;
                background-image: -o-radial-gradient(black 5px, transparent 6px);
                background-image: radial-gradient(black 5px, transparent 6px);
                background-size: 70px 70px;
                background-position-x: -12px;
            }
            .binary-card[value="2"]:after {
                background-color: white;
                background-image: -o-radial-gradient(black 5px, transparent 6px);
                background-image: radial-gradient(black 5px, transparent 6px);
                background-size: 27px 27px;
                background-repeat: repeat-x;
                background-position: -4px 23px;
            }
            .binary-card[value="4"]:after {
                background-color: white;
                background-image: -o-radial-gradient(black 5px, transparent 6px);
                background-image: radial-gradient(black 5px, transparent 6px);
                background-size: 27px 27px;
                background-position: -4px 8px;
            }
            .binary-result {
                display: inline-block;
                vertical-align: middle;
                font-size: 25px;
                font-weight: bold;
                line-height: 70px;
            }
        </style>
        <div class="binary-cards">
            <div class='binary-card' value='4'></div>
            <div class='binary-card' value='2'></div>
            <div class='binary-card' value='1'></div>
            <div class='binary-result'>= 0</div>
        </div>
    `;
    constructor() {
        super();
        this.template = document.createElement('template');
        this.template.innerHTML = this.templateString;
        this.attachShadow({ mode: 'open' });
    }

    connectedCallback() {
        if (this.shadowRoot.innerHTML !== '') return; // Prevent append twice
        this.shadowRoot.appendChild(this.template.content.cloneNode(true));
        const binaryCards = this.shadowRoot.querySelectorAll('.binary-card')
        binaryCards.forEach((card) => {
            card.addEventListener('click', event => {
                event.target.classList.toggle('flipped')
                let result = 0;
                binaryCards.forEach((card) => {
                    if (card.classList.contains('flipped')) {
                        result += parseInt(card.getAttribute('value'));
                    }
                });
                const resultDiv = this.shadowRoot.querySelector('.binary-result');
                resultDiv.innerHTML = `= ${result}`
            });
        });
    }
}

class ImageToBinary extends HTMLElement {
    templateString = `
        <style>
            .image-to-binary{
                text-align: center;
            }
            .image-result-value{
                display: inline-block;
                vertical-align: middle;
                font-family: monospace;
                font-size:clamp(10px, 3.5vw, 20px);
            }
            
            .image-result-color{
                display: inline-block;
                vertical-align: middle;
                width:40px;
                height:40px;
                border: 2px solid black;
                margin: 5px;
            }
        </style>
        <div class="image-to-binary">
            <canvas></canvas>
            <div class="image-result">
                <div class="image-result-color"></div>
                <div class='image-result-value'>= 11111111 11111111 11111111</div>
            </div>
        </div>
    `;

    constructor() {
        super();
        this.template = document.createElement('template');
        this.template.innerHTML = this.templateString;
        this.attachShadow({ mode: 'open' });
    }

    connectedCallback() {
        if (this.shadowRoot.innerHTML !== '') return; // Prevent append twice
        this.shadowRoot.appendChild(this.template.content.cloneNode(true));
        const c = this.shadowRoot.querySelector('canvas');
        const ctx = c.getContext('2d');
        const image = new Image();
        image.crossOrigin = "anonymous";
        image.src = 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Mona_Lisa%2C_by_Leonardo_da_Vinci%2C_from_C2RMF_retouched.jpg/260px-Mona_Lisa%2C_by_Leonardo_da_Vinci%2C_from_C2RMF_retouched.jpg';
        image.onload = () => {
            const imageBitmapPromise = createImageBitmap(image);
            imageBitmapPromise.then(img => {
                c.width = img.width;
                c.height = img.height;
                ctx.drawImage(img, 0, 0);
            })
        }

        c.addEventListener('click', e => {
            const x = e.pageX - c.getBoundingClientRect().x;
            const y = e.pageY - c.getBoundingClientRect().y;
            const data = ctx.getImageData(x, y, 1, 1).data;
            const resultDiv = this.shadowRoot.querySelector('.image-result-value');
            const resultColor = this.shadowRoot.querySelector('.image-result-color');
            resultColor.style = `background:rgb(${data[0]},${data[1]},${data[2]})`;
            const result = `${this.toBit(data[0])} ${this.toBit(data[1])} ${this.toBit(data[2])}`;
            resultDiv.innerHTML = `= ${result}`;
        })
    }

    toBit(int) {
        return int.toString(2).padStart(8, '0');
    }
}